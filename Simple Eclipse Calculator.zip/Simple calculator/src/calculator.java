import java.util.*;
public class calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		double num1;
		double num2;
		int operation;
		int moduloNum1;
		int moduloNum2;
		String remainder;
		
		System.out.println("Welcome to the calculator!  Will you be doing division with a remainder?");
		remainder = scan.nextLine();
		
		if(remainder.equals("yes") || remainder.equals("Yes")) {
			System.out.println("Please enter you first number and make sure it is larger than your second number.");
			moduloNum1 = scan.nextInt();
			System.out.println("Please enter your second number.");
			moduloNum2 = scan.nextInt();
			System.out.println(moduloNum1 + " divided by " + moduloNum2 + " equals " + (moduloNum1/moduloNum2) + " with a remainder of " + (moduloNum1%moduloNum2) + ".");
		} else { System.out.println("Please enter your first number.");}
		
		num1 = scan.nextDouble();
		
		System.out.println("Please enter the operation you would like to use.  \nType 1 for addition, 2 for subtraction, 3 for multiplication, 4 for division, or 5 for division with a remainder.");
		operation = scan.nextInt();
		
		System.out.println("Please enter your second number.");
		num2 = scan.nextDouble();
		
		if(operation == 1) {
			System.out.println(num1 + " plus " + num2 + " equals " + (num1+num2));
		}
		
		if(operation == 2) {
			System.out.println(num1 + " minus " + num2 + " equals " + (num1-num2));
		}
		
		if(operation == 3) {
			System.out.println(num1 + " times " + num2 + " equals " + (num1*num2));
		}
		
		if(operation == 4) {
			System.out.println(num1 + " divided by " + num2 + " equals " + (num1/num2));
		}
		
		

	}

}
